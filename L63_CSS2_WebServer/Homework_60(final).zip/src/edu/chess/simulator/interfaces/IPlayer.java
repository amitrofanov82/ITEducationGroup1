package edu.chess.simulator.interfaces;

public interface IPlayer {
	String getName();
	String setName();
}
