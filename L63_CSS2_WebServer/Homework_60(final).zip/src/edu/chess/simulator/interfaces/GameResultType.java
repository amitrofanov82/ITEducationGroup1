package edu.chess.simulator.interfaces;

public enum GameResultType {
	WHITE_WIN, BLACK_WIN, DRAW, IN_PROGRESS, END_GAME_NO_RESULT
}
