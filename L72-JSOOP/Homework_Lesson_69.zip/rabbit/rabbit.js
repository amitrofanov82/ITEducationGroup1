/* Rabbit */

var button,image,block;

function onClick() {
	jump("-20px");
	setTimeout(fallen, 400);
}

function jump(value) {
	image.style.top = "-20px";
}

function fallen() {
	image.style.top = "0px";
}


function rabbit() {
	block = document.createElement("div");
	block.setAttribute("id","block");
	
	image = document.createElement("img");
	image.setAttribute("id","image");
	image.setAttribute("src","image.png");
	
	button = document.createElement("button");
	button.setAttribute("id","button");
	button.innerHTML = "JUMP!";
	button.addEventListener("click", onClick);
	
	block.appendChild(image);
	block.appendChild(button);
	document.body.appendChild(block);
}
